package com.example.aulaOitoSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaOitoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaOitoSpringApplication.class, args);
	}

}
